const { merge } = require('webpack-merge');
const common = require('./webpack.common.js');
const path = require('path');
const proxy = require('./proxy.dev.js');
const ReactRefreshWebpackPlugin = require('@pmmmwh/react-refresh-webpack-plugin');

const devConfig = merge(common, {
    mode: 'development',
    target: 'web',
    devtool: 'source-map',
    module: {
        rules: [
            {
                test: /\.(css|less)$/,
                use: [
                    'style-loader',
                    {
                        loader: 'css-loader',
                        options: {
                            modules: {
                                localIdentName: '[name][local]_[hash:base64:4]',
                            },
                        },
                    },
                    {
                        loader: 'postcss-loader',
                        options: {
                            postcssOptions: {
                                plugins: ['postcss-preset-env'],
                            },
                        },
                    },
                    'less-loader',
                ],
            },
            {
                test: /\.[jt]sx?$/,
                enforce: 'pre',
                use: ['source-map-loader'],
                exclude: /node_modules/,
            },
            {
                test: /\.[jt]sx?$/,
                loader: 'esbuild-loader',
                options: {
                    target: 'es2015',
                    loader: 'jsx',
                },
                exclude: [/node_modules/],
            },
        ],
    },
    plugins: [new ReactRefreshWebpackPlugin()],
    devServer: {
        // 热更新开启
        hot: true,
        //编译完自动打开浏览器
        open: true,
        // 解决 BrowserRouter 跳转后刷新也面404问题
        historyApiFallback: true,
        //开启gzip压缩
        // compress: true,
        //开启端口号
        // port: 3000,
        //可通过数组的方式托管多个静态资源文件
        static: {
            directory: path.join(__dirname, '../public'),
        },
        // 接口代理
        proxy,
    },
});

module.exports = devConfig;
