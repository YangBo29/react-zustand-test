/**
 * author : yangbo
 * date : 2023/09/14 09:41:35
 * fileName: index.js
 * description :
 **/

import React, { useEffect } from 'react';
import { connect } from 'dva';
import img from '@assets/case.png';
import imgGif from '@assets/01.gif';
import imgSvg from '@assets/500.svg';
import membersSvg from '@assets/members.svg';

let name = 'Alan';

function Template(props) {
    const { count, add } = props;
    // 备注会被打到包里么
    console.log('Template-----', count);
    console.log(process?.env);

    useEffect(() => {
        const matrix = [
            [1, 2, 3],
            [4, 5, 6],
            [7, 8, 9],
        ];

        const rotate = function (matrix) {
            const r = matrix.length;
            const c = matrix[0].length;

            for (let i = 0; i < r / 2; i++) {
                for (let j = 0; j < c / 2; j++) {
                    const item = matrix[i][j];

                    matrix[c - i - 1] = matrix[i];
                }
            }
        };

        rotate(matrix);
    }, []);

    return (
        <>
            <div>
                <span>{name}</span>
                <img src={img} alt="" />
                <img src={imgGif} alt="" />
                <img src={imgSvg} alt="" />
                <img
                    src={membersSvg}
                    alt=""
                    onClick={() => {
                        add(count + 1);
                    }}
                />
            </div>
            <div>这是一次修改+++++ddddddnnnnnnnn</div>
        </>
    );
}

const mapStateToProps = state => {
    return {
        count: state.counter.count,
    };
};

const mapDispatchToProps = dispatch => {
    return {
        add: params => {
            return dispatch({
                type: 'counter/add',
                payload: params,
            });
        },
    };
};
export default connect(mapStateToProps, mapDispatchToProps)(Template);
