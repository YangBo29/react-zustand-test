/**
 * author : yangbo
 * date : 2023/09/18 13:56:32
 * fileName: index.jsx
 * description : Loading
 **/
import React from 'react';

function Loading(props) {
    console.log('我跳转路由了？');
    return <div>Loading</div>;
}

export default Loading;
