/**
 * author : yangbo
 * date : 2023/09/15 09:40:39
 * fileName: index.jsx
 * description : 公有工具包
 **/
import React from 'react';

function BaseLayer(props) {
    return <div>BaseLayer</div>;
}

export default BaseLayer;
