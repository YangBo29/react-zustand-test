/**
 * author : yangbo
 * date : 2023/09/15 09:40:18
 * fileName: auth.js
 * description : 环境工具包
 **/
