/**
 * author : yangbo
 * date : 2023/09/18 09:42:04
 * fileName: index.jsx
 * description :
 **/
import React from 'react';

function UserManage(props) {
    console.log('UserManage');
    return <div>UserManage</div>;
}

export default UserManage;
