/**
 * author : yangbo
 * date : 2023/09/18 09:42:04
 * fileName: index.jsx
 * description :
 **/
import React from 'react';

function Manage(props) {
    return <div>Manage</div>;
}

export default Manage;
