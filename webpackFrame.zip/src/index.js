/**
 * author : yangbo
 * date : 2024/07/05 17:59:12
 * fileName: index.js
 * description : 接入dva
 **/
// import React from 'react';
import dva from 'dva';
import { createBrowserHistory } from 'history';
import RouteContainer from '@routes';
import { loadModels } from './loadModels';

const app = dva({
    history: createBrowserHistory(),
});

const modelsContext = require.context('./models', false, /\.js$/);
loadModels(modelsContext, app); // 批量加载模型

app.router(RouteContainer);

app.start('#root');

export default app;
