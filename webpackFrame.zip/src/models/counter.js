/**
 * author : yangbo
 * date : 2023/09/22 17:08:44
 * fileName: counter.js
 * description : redux 空间
 **/

export default {
    namespace: 'counter',
    state: {
        count: 0,
    },
    // 事件池
    subscriptions: {},

    // dispatch
    effects: {
        *add({ payload }, { put, select, call }) {
            console.log(payload);
            yield put({ type: 'increment', payload });
        },
    },

    reducers: {
        increment(state) {
            return {
                ...state,
                count: state.count + 1,
            };
        },
    },
};
