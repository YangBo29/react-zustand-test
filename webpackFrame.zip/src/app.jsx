/**
 * author : yangbo
 * date : 2023/09/15 17:07:23
 * fileName: app.jsx
 * description : 根路由
 **/
import React from 'react';
import RouteContainer from '@routes';

function App(props) {
    return <RouteContainer />;
}

export default App;
